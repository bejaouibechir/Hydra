# Cache memoire (placeholder)

"Placeholder - a completer"


def _todo():
    """TODO: implementer ce module."""
    raise NotImplementedError
