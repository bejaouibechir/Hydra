"""
JSON Connector - Sprint 4
Projet Hydra ETL

Connecteur unique pour JSON/JSONL avec support nested intelligent.

Fonctionnalités Sprint 4:
- Extract depuis fichier local (JSON, JSONL)
- Support JSON flat
- Support JSON nested simple (1-3 niveaux)
- Auto-flatten avec pandas json_normalize
- Batch processing
- Gestion erreurs robuste

Formats supportés:
- JSON standard: {"key": "value"} ou [{"id": 1}, ...]
- JSONL (JSON Lines): {"id": 1}\n{"id": 2}\n

Limitations Sprint 4:
- URL extraction → Sprint 5+
- Load operation → Sprint 5+
- JSONPath filtering → Sprint 5+
- Schema mapping explicite → Sprint 5+

POC Validation:
- 7/7 tests passent
- Performance: 10k records en ~3s
- Approche: pandas json_normalize validée

Architecture:
    JSONConnector (hérite BaseConnector)
    ├── extract_batches()           ← Entry point
    ├── _extract_from_file()        ← Dispatch format
    ├── _extract_json()             ← JSON standard
    ├── _extract_jsonl()            ← JSON Lines
    └── _flatten_records()          ← Pandas normalize

Examples:
    >>> # JSON flat
    >>> conn = JSONConnector(name="my_json", config={
    ...     "type": "json",
    ...     "extract": {}
    ... })
    >>> for batch in conn.extract_batches(file="data.json"):
    ...     print(batch)
    
    >>> # JSON nested avec flatten
    >>> for batch in conn.extract_batches(file="nested.json", flatten_depth=2):
    ...     print(batch)
    
    >>> # JSONL avec batch_size custom
    >>> for batch in conn.extract_batches(file="events.jsonl", batch_size=5000):
    ...     print(batch)

Author: Hydra Consortium (ChatGPT, Grok, Claude)
Date: Janvier 2026
Sprint: 4
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional
import warnings

import pandas as pd
from pandas import json_normalize

from hydra_etl.internal.connector.interface import Connector, Batch


class JSONConnector(Connector):
    """
    Connecteur JSON/JSONL avec support nested intelligent.
    
    Utilise pandas json_normalize pour flatten automatique avec contrôle
    granulaire de la profondeur (0-3 niveaux).
    
    Capabilities Sprint 4:
    - supports_extract: True
    - supports_load: False (Sprint 5+)
    - supports_upsert: False
    - supports_incremental: False
    
    Formats:
    - .json: JSON standard (objet ou array)
    - .jsonl, .ndjson: JSON Lines (streaming)
    
    Configuration:
        sources:
          my_json:
            type: json
            extract:
              file: "data/users.json"      # Requis Sprint 4
              batch_size: 10000             # Optionnel (défaut: 10000)
              flatten_depth: 1              # Optionnel (0-3, défaut: 1)
    
    Args:
        name: Nom du connecteur
        config: Configuration (type, extract, etc.)
    
    Attributes:
        _extract_cfg: Configuration extract depuis config
    
    Raises:
        ValueError: Configuration invalide
        FileNotFoundError: Fichier introuvable
        JSONDecodeError: JSON invalide
    """
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Initialise le connecteur JSON.

        Args:
            name: Nom du connecteur (pour logs)
            config: Dict avec 'type', 'extract', etc.
        """
        super().__init__(name=name, config=config)
        self._extract_cfg = config.get("extract", {})
        # job_dir pour résolution des chemins relatifs (injecté par l'executor comme pour CSV)
        from pathlib import Path as _Path
        self._job_dir = _Path(config["job_dir"]).resolve() if "job_dir" in config else None
    
    # ========================================================================
    # Capabilities
    # ========================================================================
    
    def supports_extract(self) -> bool:
        """
        Support extraction.
        
        Returns:
            True (toujours pour Sprint 4)
        """
        return True
    
    def supports_load(self) -> bool:
        """
        Support load (write).
        
        Returns:
            False (Sprint 5+)
        """
        return False
    
    def get_capabilities(self) -> Dict[str, Any]:
        """
        Retourne capabilities du connecteur.
        
        Returns:
            Dict avec features supportées
        """
        return {
            "supports_extract": True,
            "supports_load": False,
            "supports_upsert": False,
            "supports_incremental": False,
            "formats": ["json", "jsonl", "ndjson"],
            "flatten_max_depth": 3,
            "streaming": True,
        }
    
    def test_connection(self) -> None:
        """
        Test connection pour JSON connector.
        
        Pour JSON (fichier local), on vérifie juste que le fichier
        existe et est lisible (si spécifié dans config).
        
        Raises:
            ValueError: Si fichier spécifié mais introuvable/illisible
        """
        # Pour JSON, pas vraiment de "connexion" à tester
        # On pourrait vérifier le fichier s'il est dans config
        file_path = self._extract_cfg.get("file")
        
        if file_path:
            path = Path(file_path)
            if not path.exists():
                raise ValueError(
                    f"{self.__class__.__name__} [{self.name}]: "
                    f"test file not found: {file_path}"
                )
            if not path.is_file():
                raise ValueError(
                    f"{self.__class__.__name__} [{self.name}]: "
                    f"path is not a file: {file_path}"
                )
        # Pas de fichier dans config → connexion OK (sera fourni à extract_batches)
    
    def load_batches(
        self,
        batches,
        *,
        table: str,
        mode: str = "append",
        key: Optional[List[str]] = None,
    ) -> None:
        """
        Load batches (non implémenté Sprint 4).
        
        Sprint 5+ : Écriture JSON/JSONL.
        
        Raises:
            NotImplementedError: Sprint 5+
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} [{self.name}]: "
            f"load is not available. "
            f"only extract is supported."
        )
    
    # ========================================================================
    # Extract - Entry Point
    # ========================================================================
    
    def extract_batches(
        self,
        *,
        table: Optional[str] = None,
        query: Optional[str] = None,
        batch_size: int = 10_000,
        incremental: Optional[Any] = None,
        # Params hérités pour usage direct (rétrocompatibilité)
        file: Optional[str] = None,
        flatten_depth: int = 1,
        json_path: Optional[str] = None,
    ) -> Iterator[Batch]:
        """
        Extrait batches depuis JSON/JSONL.

        Conforme à l'interface Connector : accepte 'table' comme chemin de fichier
        (résolu relativement à job_dir si non absolu), identique à CSVConnector.

        Args:
            table: Chemin du fichier JSON (interface standard executor)
            query: Ignoré pour JSON (pas de SQL)
            batch_size: Taille des batches
            incremental: Ignoré (Sprint 5+)
            file: Alias legacy pour 'table' (usage direct)
            flatten_depth: Profondeur auto-flatten (0-3, défaut: 1)
            json_path: JSONPath filtering (Sprint 5+, non implémenté)
        """
        if json_path:
            raise NotImplementedError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"JSONPath filtering is not available yet."
            )

        if not isinstance(flatten_depth, int) or not 0 <= flatten_depth <= 3:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"'flatten_depth' must be between 0 and 3, got: {flatten_depth}"
            )

        if not isinstance(batch_size, int) or batch_size < 1:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"'batch_size' must be >= 1, got: {batch_size}"
            )

        # Résolution du chemin : table > file > config
        resolved_file = table or file or self._extract_cfg.get("file") or self._extract_cfg.get("table")

        if not resolved_file:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"file path required ('table' or 'file')."
            )

        # Résolution relative via job_dir (comme CSVConnector)
        from pathlib import Path as _Path
        p = _Path(str(resolved_file))
        if not p.is_absolute() and self._job_dir is not None:
            p = self._job_dir / p
        resolved_file = str(p)

        # Extraction depuis fichier
        yield from self._extract_from_file(
            file=resolved_file,
            batch_size=batch_size,
            flatten_depth=flatten_depth,
        )
    
    # ========================================================================
    # Extract - Helpers
    # ========================================================================
    
    def _extract_from_file(
        self,
        *,
        file: str,
        batch_size: int,
        flatten_depth: int,
    ) -> Iterator[Batch]:
        """
        Extraction depuis fichier local.
        
        Détecte automatiquement le format basé sur l'extension:
        - .json → JSON standard (objet ou array)
        - .jsonl, .ndjson → JSON Lines (streaming)
        - Autres → Tentative JSON standard avec warning
        
        Args:
            file: Chemin fichier
            batch_size: Taille batches
            flatten_depth: Profondeur flatten
        
        Yields:
            Batch
        
        Raises:
            FileNotFoundError: Fichier introuvable
            ValueError: Fichier n'est pas un fichier régulier
        """
        file_path = Path(file)
        
        # Validation existence
        if not file_path.exists():
            raise FileNotFoundError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"file not found: {file}\n"
                f"  Absolute path: {file_path.absolute()}"
            )
        
        if not file_path.is_file():
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"path is not a regular file: {file}"
            )
        
        # Détection format par extension
        suffix = file_path.suffix.lower()
        
        if suffix in [".jsonl", ".ndjson"]:
            # JSON Lines (streaming)
            yield from self._extract_jsonl(file_path, batch_size, flatten_depth)
        
        elif suffix in [".json"]:
            # JSON standard
            yield from self._extract_json(file_path, batch_size, flatten_depth)
        
        else:
            # Extension inconnue → tentative JSON standard avec warning
            warnings.warn(
                f"{self.__class__.__name__} [{self.name}]: "
                f"unknown extension '{suffix}' for file '{file_path.name}'. "
                f"Reading it as standard JSON.",
                RuntimeWarning
            )
            yield from self._extract_json(file_path, batch_size, flatten_depth)
    
    def _extract_json(
        self,
        file_path: Path,
        batch_size: int,
        flatten_depth: int,
    ) -> Iterator[Batch]:
        """
        Extraction JSON standard.
        
        Supporte:
        - Objet unique: {"key": "value"}
        - Array d'objets: [{"id": 1}, {"id": 2}]
        
        Args:
            file_path: Path objet
            batch_size: Taille batches
            flatten_depth: Profondeur flatten
        
        Yields:
            Batch
        
        Raises:
            ValueError: JSON invalide ou format non supporté
        """
        # Lecture fichier complet
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        
        except json.JSONDecodeError as e:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"invalid JSON in '{file_path.name}'.\n"
                f"  Line {e.lineno}, column {e.colno}: {e.msg}\n"
                f"  Check the JSON syntax with a validator."
            ) from e
        
        except UnicodeDecodeError as e:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"invalid encoding in '{file_path.name}'. "
                f"The file must be UTF-8.\n"
                f"  Error: {e}"
            ) from e
        
        except Exception as e:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"read error '{file_path.name}': {e}"
            ) from e
        
        # Normaliser en liste de records
        if isinstance(data, dict):
            # Objet unique → liste de 1 élément
            records = [data]
        
        elif isinstance(data, list):
            # Array → déjà liste
            if not data:
                # Liste vide → return sans yield
                return
            records = data
        
        else:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"unsupported JSON layout in '{file_path.name}'. "
                f"Expected: dict or list, got: {type(data).__name__}\n"
                f"  The file must contain an object {{}} or an array []."
            )
        
        # Flatten si demandé
        if flatten_depth > 0:
            records = self._flatten_records(records, flatten_depth)
        
        # Yield par batches
        for i in range(0, len(records), batch_size):
            batch = records[i:i + batch_size]
            yield batch
    
    def _extract_jsonl(
        self,
        file_path: Path,
        batch_size: int,
        flatten_depth: int,
    ) -> Iterator[Batch]:
        """
        Extraction JSONL (JSON Lines).
        
        Format: 1 objet JSON par ligne.
        Optimisé pour streaming (pas de chargement complet en mémoire).
        
        Args:
            file_path: Path objet
            batch_size: Taille batches
            flatten_depth: Profondeur flatten
        
        Yields:
            Batch
        
        Raises:
            ValueError: JSON invalide sur une ligne
        """
        batch = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, start=1):
                    line = line.strip()
                    
                    # Ignorer lignes vides
                    if not line:
                        continue
                    
                    # Parse JSON
                    try:
                        record = json.loads(line)
                    except json.JSONDecodeError as e:
                        raise ValueError(
                            f"{self.__class__.__name__} [{self.name}]: "
                            f"invalid JSON in '{file_path.name}' line {line_num}.\n"
                            f"  Error: {e.msg}\n"
                            f"  Line: {line[:100]}..."
                        ) from e
                    
                    batch.append(record)
                    
                    # Yield batch si plein
                    if len(batch) >= batch_size:
                        if flatten_depth > 0:
                            batch = self._flatten_records(batch, flatten_depth)
                        yield batch
                        batch = []
                
                # Yield dernier batch (peut être partiel)
                if batch:
                    if flatten_depth > 0:
                        batch = self._flatten_records(batch, flatten_depth)
                    yield batch
        
        except UnicodeDecodeError as e:
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"invalid encoding in '{file_path.name}'. "
                f"The file must be UTF-8.\n"
                f"  Error: {e}"
            ) from e
        
        except Exception as e:
            # Re-raise si déjà ValueError
            if isinstance(e, ValueError):
                raise
            
            raise ValueError(
                f"{self.__class__.__name__} [{self.name}]: "
                f"read error '{file_path.name}': {e}"
            ) from e
    
    def _flatten_records(
        self,
        records: List[Dict[str, Any]],
        flatten_depth: int,
    ) -> List[Dict[str, Any]]:
        """
        Flatten nested JSON avec pandas json_normalize.
        
        Utilise pandas.json_normalize qui gère:
        - Nested objects (user.name → user.name)
        - Max depth control
        - Missing keys → NaN (converti en None)
        
        Si flatten échoue, retourne records originaux avec warning
        (graceful degradation).
        
        Args:
            records: Liste de dict (JSON objects)
            flatten_depth: Profondeur (1-3)
        
        Returns:
            Liste de dict flatten (ou originaux si échec)
        
        Notes:
            - NaN pandas converti en None pour compatibilité JSON
            - Flatten failure → warning + return original
        
        Examples:
            >>> records = [{"id": 1, "user": {"name": "Alice"}}]
            >>> flatten_records(records, 1)
            [{"id": 1, "user.name": "Alice"}]
        """
        if not records:
            return records

        # Chemin rapide (étape 0-bis) : enregistrements déjà plats et homogènes.
        # json_normalize n'y changerait rien mais coûte l'essentiel du temps
        # d'extraction (deepcopy interne). Voir _is_flat_homogeneous.
        if self._is_flat_homogeneous(records):
            return records

        try:
            # Pandas json_normalize (POC validé)
            df = json_normalize(records, max_level=flatten_depth)
            
            # Convertir NaN → None (pour JSON serialization)
            df = df.where(pd.notna(df), None)
            
            # Convertir back to list of dict
            return df.to_dict('records')
        
        except Exception as e:
            # Flatten échoué → warning + return original (graceful degradation)
            warnings.warn(
                f"{self.__class__.__name__} [{self.name}]: "
                f"flatten failed (depth={flatten_depth}). "
                f"Data returned without flattening.\n"
                f"  Error: {type(e).__name__}: {e}\n"
                f"  Hint: check the data structure or lower flatten_depth.",
                RuntimeWarning
            )
            return records

    # Types de colonne pour lesquels json_normalize + where + to_dict rend les
    # valeurs à l'identique (même type, même valeur). Exclus volontairement :
    # None (devient NaN ou None selon la version de pandas), mélanges int/float
    # (int converti en float), dict (aplati), NaN, listes.
    _FAST_PATH_TYPES = (frozenset({str}), frozenset({bool}), frozenset({int}), frozenset({float}))

    @classmethod
    def _is_flat_homogeneous(cls, records: List[Any]) -> bool:
        """
        Vrai si json_normalize laisserait `records` strictement inchangé :
        - chaque enregistrement est un dict avec exactement les mêmes clés,
          dans le même ordre ;
        - chaque colonne ne contient qu'un seul type parmi str, bool, int, float ;
        - aucun float NaN.
        Parité vérifiée par fuzzing contre l'ancien chemin (bench/json_fast_exp.py).
        """
        first = records[0]
        if not isinstance(first, dict) or not first:
            return False
        keys = list(first)
        types: Dict[str, set] = {k: set() for k in keys}
        for r in records:
            if not isinstance(r, dict) or list(r) != keys:
                return False
            for k, v in r.items():
                types[k].add(type(v))
        for k, ts in types.items():
            if frozenset(ts) not in cls._FAST_PATH_TYPES:
                return False
            if float in ts and any(r[k] != r[k] for r in records):  # NaN
                return False
        return True