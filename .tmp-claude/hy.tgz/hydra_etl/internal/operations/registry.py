# Registry d'operations (placeholder)

"Placeholder - a completer"


def _todo():
    """TODO: implementer ce module."""
    raise NotImplementedError
