from hydra_etl.mcp.server import main

if __name__ == "__main__":
    main()
