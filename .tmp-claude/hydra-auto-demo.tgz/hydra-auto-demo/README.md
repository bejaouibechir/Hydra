# hydra-auto-demo — test scenario: running a project automatically

What can already be automated in Hydra 0.18, tested from the CLI, Studio and VS Code.
The new project-level automation (sub-projects, `triggers.yaml`, `hdrctl watch`, file
events) comes with 0.19: this scenario will grow with it.

```
inbox/orders.csv ──► ingest ──► data/staging.csv ──► report ──► out/report.csv
                     (fallback: ingest_backup reads data/backup/orders.csv)
heartbeat  : schedule, every minute → out/heartbeat.log
on_demand  : webhook → rebuilds out/report.csv
```

| Workflow | Trigger | In `thread.yaml` | Role |
|---|---|---|---|
| `ingest` | manual | stage 1, `timeout: 2m`, fallback | keeps the paid orders of `inbox/orders.csv` |
| `ingest_backup` | manual | fallback of `ingest` | same, from `data/backup/orders.csv` |
| `report` | manual | stage 2, `delay_before: 2s`, loop × 2 | revenue per country → `out/report.csv` |
| `heartbeat` | `schedule` `*/1 * * * *` | no | appends the time to `out/heartbeat.log` |
| `on_demand` | `webhook` | no | rebuilds the report on an HTTP call |

## 0. Prerequisites

```powershell
pip install -e "C:\Users\DELL\Desktop\Hydra[server]"
cd D:\data\hydra-auto-demo
```
No database: everything is CSV.

## 1. CLI — run the whole project

```powershell
hdrctl workflow list
hdrctl run .
```
Expected:
- `workflow list`: `ingest` and `report` in the thread, `ingest_backup` as fallback of `ingest`,
  `heartbeat` and `on_demand` "not in thread.yaml (not run by hdrctl run)".
- `run .`: stage 1 `ingest`; then "report: waiting 2s", `report (pass 1/2)`,
  "Loop report → report: pass 2/2 — waiting 3s", `report (pass 2/2)`. The `show` step prints:
  ```
  country,revenue,orders
  TN,380.0,2
  ES,210.0,1
  FR,165.0,2
  ```

## 2. CLI — fallback

```powershell
Rename-Item inbox\orders.csv orders.csv.off
hdrctl run .
Rename-Item inbox\orders.csv.off orders.csv
```
Expected: `Fallback: ingest → ingest_backup — file_exists('inbox/orders.csv') = false`, the line
"inbox/orders.csv missing - backup file used", then a report with only TN 20 and FR 10.

## 3. CLI — one workflow, deactivate, check

```powershell
hdrctl workflow run heartbeat            # one tick, also written to out\heartbeat.log
hdrctl workflow validate report
hdrctl run . --dry-run                   # checks without running
```
Then edit `workflows\thread.yaml`: set `active: false` on `report`, run `hdrctl run .`
(only `ingest` runs), and set `active: true` back.

The cron of `heartbeat` is **not** run by the CLI: schedules and webhooks run inside `hdrctl serve`.

## 4. Studio — run, schedule, webhook

```powershell
hdrctl serve --open
```
1. **Open** the project `D:\data\hydra-auto-demo`. The workflow cards show their trigger
   (Manual / Schedule / Webhook).
2. **Project settings › Execution order**: the two stages, the `delay_before` of `report`,
   the fallback of `ingest`, the loop. **Check**, then **Preview**.
3. Project page › **Run project**: the run page shows `ingest`, then `report` twice.
4. **Schedule**: leave Studio running 2–3 minutes. **Runs** lists `heartbeat` runs with trigger
   `schedule`; `out\heartbeat.log` gets one line per minute. To stop it, set the trigger of the
   `heartbeat` card to Manual.
5. **Webhook**: open `on_demand` in the editor; the address bar shows
   `/workflows/<WORKFLOW_ID>?projectId=<PROJECT_ID>`. Then, in PowerShell:
   ```powershell
   Remove-Item out\report.csv
   Invoke-RestMethod -Method Post "http://127.0.0.1:5678/api/workflows/<WORKFLOW_ID>/trigger?project_id=<PROJECT_ID>"
   ```
   The answer is a run with `"trigger": "webhook"`; `out\report.csv` is back and **Runs** shows it.
   The same call on `report` (manual trigger) is refused: `trigger is 'manual', not 'webhook'`.
6. Scheduled workflows: `http://127.0.0.1:5678/api/workflows/scheduled/list`.

## 5. VS Code extension (0.1.7)

Open `D:\data\hydra-auto-demo` in VS Code.
- `workflows\thread.yaml`: `mode: random` → error; remove `use:` from the fallback → error;
  `delay_before: soon` → error. Hover `fallback` and `when` for help (`file_exists`,
  `source_available`…).
- `workflows\heartbeat.yaml`: remove the `cron:` line → "cron is required"; in a new workflow,
  `htrigger-cron` + Tab inserts a schedule.
- `workflows\on_demand.yaml`: `type: webhook` is accepted; `type: hourly` is refused.

## Known limits (today)

- Schedules and webhooks are per **workflow** and run only while `hdrctl serve` runs.
- A scheduled or webhook run uses **no environment**: only the common global variables and the
  default parameter values. Project triggers with an environment come with 0.19.
- The webhook asks for no token: keep `hdrctl serve` on `127.0.0.1`.

## Clean up

```powershell
Remove-Item out\*.csv, out\heartbeat.log, data\staging.csv
```
Set the `heartbeat` trigger back to Manual, or stop `hdrctl serve`.
