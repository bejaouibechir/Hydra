# hydra-env-demo — test scenario: environment variables, parameters, secrets

PostgreSQL `orders` → filter → revenue per country → MySQL `revenue_by_country`.
The same project runs against **dev** or **prod**: other databases, another MySQL user,
other parameter values, another password.

| What | Where | dev | prod |
|---|---|---|---|
| Global variables (all projects) | `~/.hydra/env`, `~/.hydra/env.<env>` | `shop_dev` → `dw_dev` as `etl_dev` | `shop_prod` → `dw_prod` as `etl_prod` |
| Parameters | `parameters.yaml`, `environments/<env>.yaml` | `min_amount` 50, `batch_size` 500 (default) | `min_amount` 100, `batch_size` 5000 |
| Secrets | `.hydra/secrets`, `.hydra/secrets.<env>` | `pg.password` (common), `mysql.password` = Dev_Pass_123 | `mysql.password` = Prod_Pass_456 |

## 0. Prerequisites

```powershell
pip install -e "C:\Users\DELL\Desktop\Hydra[server,postgres,mysql]"
hdrctl --version
cd D:\data\hydra-env-demo
```

## 1. Databases (Docker Desktop)

```powershell
docker run -d --name hydra-env-pg -e POSTGRES_USER=hydra -e POSTGRES_PASSWORD=Pg_Pass_789 -p 55432:5432 -v "${PWD}\docker\postgres:/docker-entrypoint-initdb.d:ro" postgres:16-alpine
docker run -d --name hydra-env-mysql -e MYSQL_ROOT_PASSWORD=Root_Pass_000 -p 33306:3306 -v "${PWD}\docker\mysql:/docker-entrypoint-initdb.d:ro" mysql:8.4
docker ps
```
Wait ~30 s for MySQL. To start over: `docker rm -f hydra-env-pg hydra-env-mysql`, then the two `docker run` again.

## 2. CLI — set up

Global variables (shared by every project):
```powershell
hdrctl env create dev
hdrctl env create prod
hdrctl env set PG_HOST 127.0.0.1
hdrctl env set PG_PORT 55432
hdrctl env set PG_USER hydra
hdrctl env set MYSQL_HOST 127.0.0.1
hdrctl env set MYSQL_PORT 33306
hdrctl env set PG_DATABASE shop_dev --env dev
hdrctl env set MYSQL_DATABASE dw_dev --env dev
hdrctl env set MYSQL_USER etl_dev --env dev
hdrctl env set PG_DATABASE shop_prod --env prod
hdrctl env set MYSQL_DATABASE dw_prod --env prod
hdrctl env set MYSQL_USER etl_prod --env prod
hdrctl env list
hdrctl env show prod
```
`env create` says "already exists" if you created dev/prod before: ignore it.

Secrets (each value is typed twice, hidden):
```powershell
hdrctl secret set pg.password                 # Pg_Pass_789
hdrctl secret set mysql.password --env dev    # Dev_Pass_123
hdrctl secret set mysql.password --env prod   # Prod_Pass_456
hdrctl secret list --env prod
```

Parameters (already in the project):
```powershell
hdrctl param list
```

## 3. CLI — run

```powershell
hdrctl run . --env dev
hdrctl run . --env prod
hdrctl run . --env prod -P min_amount=1000
hdrctl run . --env dev --secrets-visibility plain
hdrctl run .
hdrctl run jobs\sync_orders --env dev
```

Expected:

| Command | First step prints | `revenue_by_country` |
|---|---|---|
| `--env dev` | `shop_dev`, `dw_dev as etl_dev`, `min_amount = 50.0, batch_size = 500`, `password = [MASKED]` | dw_dev: TN 380 (2), ES 210 (1), FR 120 (1) |
| `--env prod` | `shop_prod`, `dw_prod as etl_prod`, `min_amount = 100.0, batch_size = 5000` | dw_prod: ES 2400, TN 1920 (2), FR 950, DE 130 |
| `--env prod -P min_amount=1000` | `min_amount = 1000` | dw_prod: ES 2400, TN 1500 |
| `--secrets-visibility plain` | `password = Dev_Pass_123` | — |
| no `--env` | fails: `Missing environment variable: PG_DATABASE` (normal: it only exists in dev/prod) | — |

Check the tables:
```powershell
docker exec hydra-env-mysql mysql -uroot -pRoot_Pass_000 -e "select * from dw_dev.revenue_by_country; select * from dw_prod.revenue_by_country"
```

Error cases worth trying:
- `hdrctl secret delete mysql.password --env dev`, then `hdrctl run . --env dev` → missing secret (then set it again).
- `hdrctl param set min_amount abc --env dev` → refused: not a valid float.
- `hdrctl env set PG_PORT 5999 --env dev`, then `hdrctl run . --env dev` → connection refused; `hdrctl env unset PG_PORT --env dev` repairs it (the common value comes back).
- `--env-file`: create `extra.env` with `MYSQL_USER=etl_prod`, then `hdrctl run . --env dev --env-file extra.env` → access denied to dw_dev (the file wins over everything).

## 4. Studio

```powershell
hdrctl serve --open
```
1. Open the project `D:\data\hydra-env-demo`.
2. **Settings › Global settings › Environments**: Common, dev, prod show the variables set by the CLI. Add `TEST_VAR=1` to dev, Save, check with `hdrctl env show dev`.
3. **Project settings › Parameters**: columns default / dev / prod. Change `min_amount` for dev to 200, Save, check `environments/dev.yaml`.
4. **Project settings › Secrets**: "Secrets for" Common / dev / prod; values never shown. Replace `mysql.password` for dev with a wrong value → next dev run fails; put back `Dev_Pass_123`.
5. Project page: **Environment = dev**, Run project → run logs show dw_dev values; switch to **prod**, run again.
6. Open `main` in the editor: the same environment is in the header. Run Workflow; open a field's Expression Assistant ({x}): parameter values are those of the active environment.
7. Set the environment back to **default (no environment)** and run → fails on `PG_DATABASE`, like the CLI.

## 5. VS Code extension

Open `D:\data\hydra-env-demo` in VS Code (extension 0.1.6):
- `jobs/sync_orders/*.yaml`: completion and validation (e.g. rename `type: postgresql` to `type: postgres` → error).
- Snippets in `transformations.yaml`: `hwindow`, `htexttorows`, `hcrossjoin`.
- `parameters.yaml`, `environments/*.yaml`, `.hydra/secrets.yaml`: no schema yet (phase D).

## 6. Clean up

```powershell
docker rm -f hydra-env-pg hydra-env-mysql
hdrctl env delete dev --project . -y
hdrctl env delete prod --project . -y
```
`env delete` keeps a copy in `~/.hydra/_backups/`.
