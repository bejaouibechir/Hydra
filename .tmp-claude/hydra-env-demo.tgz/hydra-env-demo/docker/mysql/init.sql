-- Two target databases, one user per environment (each user sees only its database).
CREATE DATABASE dw_dev;
CREATE DATABASE dw_prod;
CREATE USER 'etl_dev'@'%'  IDENTIFIED BY 'Dev_Pass_123';
CREATE USER 'etl_prod'@'%' IDENTIFIED BY 'Prod_Pass_456';
GRANT ALL PRIVILEGES ON dw_dev.*  TO 'etl_dev'@'%';
GRANT ALL PRIVILEGES ON dw_prod.* TO 'etl_prod'@'%';
FLUSH PRIVILEGES;
-- Target table of the job (the MySQL connector does not create tables).
CREATE TABLE dw_dev.revenue_by_country  (country VARCHAR(10), revenue DECIMAL(12,2), orders INT);
CREATE TABLE dw_prod.revenue_by_country (country VARCHAR(10), revenue DECIMAL(12,2), orders INT);
