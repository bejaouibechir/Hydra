-- Two source databases, same table, different data: shop_dev and shop_prod.
CREATE DATABASE shop_dev;
CREATE DATABASE shop_prod;
\c shop_dev
CREATE TABLE orders (order_id INT PRIMARY KEY, country TEXT, amount NUMERIC(10,2), status TEXT);
INSERT INTO orders VALUES
 (1,'FR',  45.00,'paid'), (2,'FR', 120.00,'paid'), (3,'TN',  80.00,'paid'),
 (4,'TN', 300.00,'paid'), (5,'ES',  15.00,'cancelled'), (6,'ES', 210.00,'paid');
\c shop_prod
CREATE TABLE orders (order_id INT PRIMARY KEY, country TEXT, amount NUMERIC(10,2), status TEXT);
INSERT INTO orders VALUES
 (101,'FR', 950.00,'paid'), (102,'FR',  60.00,'paid'), (103,'TN', 1500.00,'paid'),
 (104,'TN', 420.00,'paid'), (105,'ES',  99.00,'paid'), (106,'ES', 2400.00,'paid'),
 (107,'DE', 130.00,'paid'), (108,'DE',  30.00,'cancelled');
