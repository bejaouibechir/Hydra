# Comparatif : Hydra ETL vs dlt + dbt + Airflow

Même chaîne, mêmes données, mêmes pannes. Tout tourne en local, sans serveur
ni base de données (CSV en entrée, CSV en sortie ; DuckDB côté dbt).

**Chaîne** : commandes (200 000 lignes) + clients (2 000) → commandes payées →
chiffre d'affaires par pays (jointure) et par mois. Deux sorties :
`output/revenue_by_country.csv`, `output/revenue_by_month.csv`.

**Pannes rejouées** (`shared/scenarios.py`) — avant chaque run, les sorties
contiennent le run de l'avant-veille (« previous ») :

| Scénario | Panne |
|---|---|
| normal | aucune |
| missing_source | `data/orders.csv` absent |
| bad_amount | un montant illisible (`abc`) : la 1re sortie échoue |
| bad_date | une date impossible (`2026-13-45`) : seule la 2e sortie échoue |

Une source de secours existe : `data/backup/orders.csv` (export de la veille,
199 000 lignes). Le script dit, pour chaque sortie, de quelle version elle
vient : `main` (jour), `backup` (veille), `previous` (avant-veille) ou `other`.

## Lancer

```bash
python shared/make_data.py shared/data            # données (graine fixe)

# Hydra ETL
pip install hydra-etl                             # >= 0.14 pour on_failure / timeout
python shared/scenarios.py hydra_simple "hdrctl run ."
python shared/scenarios.py hydra        "hdrctl run ."

# dlt + dbt + Airflow
pip install "apache-airflow==3.3.2" --constraint \
  https://raw.githubusercontent.com/apache/airflow/constraints-3.3.2/constraints-3.13.txt
pip install "dlt[duckdb]" dbt-duckdb pandas pyarrow
cd modern && source env.sh && airflow db migrate && cd ..
python shared/scenarios.py modern "source env.sh && airflow dags test daily_revenue_simple"
python shared/scenarios.py modern "source env.sh && airflow dags test daily_revenue_safe"
```

Variantes : *simple* = ce qu'on écrit d'habitude ; *safe* = secours si la
source manque ou si le calcul échoue, et sorties publiées en tout ou rien.
