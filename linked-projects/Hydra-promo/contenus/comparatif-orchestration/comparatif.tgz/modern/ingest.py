"""Chargement des CSV dans DuckDB avec dlt (couche « EL »)."""
import sys

import dlt
import pandas as pd

ORDERS = sys.argv[1] if len(sys.argv) > 1 else "data/orders.csv"


@dlt.resource(name="orders", write_disposition="replace")
def orders():
    for chunk in pd.read_csv(ORDERS, dtype=str, chunksize=50_000):
        yield chunk                      # DataFrame : chemin rapide (Arrow)


@dlt.resource(name="customers", write_disposition="replace")
def customers():
    yield pd.read_csv("data/customers.csv", dtype=str)


if __name__ == "__main__":
    pipeline = dlt.pipeline(pipeline_name="daily_revenue", destination=dlt.destinations.duckdb("warehouse.duckdb"),
                            dataset_name="raw")
    print(pipeline.run([orders(), customers()]))
