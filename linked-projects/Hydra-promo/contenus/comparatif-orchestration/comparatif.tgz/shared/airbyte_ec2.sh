#!/usr/bin/env bash
# Mesure l'installation d'Airbyte (méthode officielle abctl) sur une EC2 jetable.
# Ubuntu 24.04, t3.xlarge (4 vCPU, 16 Go) recommandé ; t3.large + --low-resource-mode au minimum.
# Usage : bash airbyte_ec2.sh [--low-resource-mode]   → écrit airbyte_report.txt
set -u
R=airbyte_report.txt
exec > >(tee "$R") 2>&1
echo "== machine"; nproc; free -m | sed -n 2p; df -h / | tail -1; uname -r
T0=$(date +%s)
echo "== docker"
curl -fsSL https://get.docker.com | sudo sh >/dev/null
sudo usermod -aG docker "$USER"
T1=$(date +%s); echo "docker_install_seconds=$((T1-T0))"
echo "== abctl"
curl -LsfS https://get.airbyte.com | bash - >/dev/null
T2=$(date +%s); echo "abctl_install_seconds=$((T2-T1))"
echo "== airbyte"
sudo DO_NOT_TRACK=1 abctl local install "$@"
RC=$?
T3=$(date +%s); echo "airbyte_install_exit=$RC airbyte_install_seconds=$((T3-T2))"
echo "total_seconds=$((T3-T0))"
echo "== ressources après installation"
free -m | sed -n 2p
sudo docker stats --no-stream --format '{{.Name}} {{.CPUPerc}} {{.MemUsage}}'
sudo docker exec airbyte-abctl-control-plane crictl images 2>/dev/null | tail -n +2 | wc -l | sed 's/^/images: /'
sudo docker exec airbyte-abctl-control-plane sh -c 'du -sh /var/lib/containerd' 2>/dev/null
sudo docker exec airbyte-abctl-control-plane crictl ps 2>/dev/null | tail -n +2 | wc -l | sed 's/^/running containers: /'
echo "== fin : copiez le contenu de $R dans la conversation, puis supprimez l'instance"
