"""
server.py — Serveur MCP local de Hydra.

Expose le moteur Hydra à l'assistant IA de l'utilisateur : découvrir le DSL,
lire et écrire des jobs, les **valider**, les exécuter. Le serveur ne contient
aucun modèle et n'émet aucune requête réseau — c'est le client qui apporte
l'intelligence.

Trois principes de conception, qui expliquent la forme des outils :

1. **Les descriptions sont l'interface.** Elles sont lues par un modèle, pas
   par un humain. Chacune dit ce que l'outil fait, quand s'en servir, et le
   piège à éviter.
2. **Aucune écriture sans validation.** `hydra_write_job` refuse d'écrire un
   job que l'oracle rejette : un agent ne peut pas laisser derrière lui un
   dossier invalide.
3. **Aucune exécution implicite.** Écrire n'exécute pas. `hydra_run_job` est un
   appel distinct, que l'utilisateur voit passer.

Lancement :
    hydra-mcp                 # transport stdio, pour un client MCP
    python -m hydra_etl.mcp   # équivalent
"""
from __future__ import annotations

import inspect
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

from hydra_etl import __version__

try:
    from mcp.types import ToolAnnotations
except ModuleNotFoundError:                             # pragma: no cover
    ToolAnnotations = None                              # type: ignore[assignment]

try:
    from mcp.server.mcpserver import MCPServer          # SDK MCP 2.x
except ModuleNotFoundError:                             # pragma: no cover
    try:
        from mcp.server.fastmcp import FastMCP as MCPServer   # SDK MCP 1.x
    except ModuleNotFoundError:
        raise SystemExit(
            "The MCP SDK is missing. Install it with:\n"
            "    pip install \"hydra-etl[mcp]\"\n"
        ) from None

import yaml

ROOT = Path(__file__).resolve().parents[2]

# La spécification est embarquée dans le paquet ; la copie du dépôt sert de
# repli quand on travaille depuis les sources. Sans la première, tout ce qui
# lit la spécification échoue une fois `pip install` fait.
_PACKAGE_SCHEMAS = Path(__file__).resolve().parent.parent / "ai" / "schemas"
_REPO_SCHEMAS = ROOT / "documentations" / "chatbot-hydra-dsl" / "schemas"
SCHEMAS = _PACKAGE_SCHEMAS if (_PACKAGE_SCHEMAS / "index.json").exists() else _REPO_SCHEMAS

JOB_FILES = ("sources.yaml", "transformations.yaml",
             "destinations.yaml", "pipeline.yaml")


def _annot(*, readonly: bool = False, destructive: bool = False,
           title: str = "") -> Any:
    """
    Annotations lues par le client MCP.

    Une consigne écrite dans une description ne retient pas un agent : à
    l'essai, un modèle a exécuté un job sans qu'on le lui demande, alors que la
    description l'interdisait. Les annotations, elles, sont lues par le client,
    qui peut demander confirmation avant une action destructive — c'est une
    barrière de protocole, pas une prière.
    """
    if ToolAnnotations is None:                         # pragma: no cover
        return None
    return ToolAnnotations(
        title=title or None,
        readOnlyHint=readonly,
        destructiveHint=destructive,
        idempotentHint=readonly,
        openWorldHint=False,
    )


LECTURE = dict(readonly=True)
ECRITURE = dict(destructive=False)
EXECUTION = dict(destructive=True)

CORPUS = ROOT / "eval" / "corpus" / "corpus.jsonl"


# ---------------------------------------------------------------------------
# Racine de travail : l'agent ne sort pas du dossier autorisé
# ---------------------------------------------------------------------------

def workspace() -> Path:
    """Dossier dans lequel l'agent a le droit de lire et d'écrire."""
    return Path(os.environ.get("HYDRA_MCP_WORKSPACE", Path.cwd())).resolve()


def safe_path(relative: str) -> Path:
    """
    Résout un chemin **à l'intérieur** de l'espace de travail.

    Un agent peut se tromper, ou suivre une consigne malveillante trouvée dans
    un fichier de données. On refuse tout ce qui sort de la racine.

    Trois contrôles, et non un seul, parce qu'aucun ne suffit :

    1. Les séparateurs sont normalisés. Sans cela, une suite de ".." séparés
       par des antislashs s'évaderait sous
       Windows tout en passant pour un simple nom de fichier sous Linux — le
       serveur n'aurait pas le même comportement selon la machine.
    2. Les chemins absolus et les segments `..` sont refusés explicitement.
    3. Le résultat résolu doit rester sous la racine — dernier filet, qui
       attrape aussi les liens symboliques.
    """
    base = workspace()
    normalized = relative.replace("\\", "/").strip()

    if not normalized or normalized in (".", "./"):
        return base
    if normalized.startswith("/") or (len(normalized) > 1 and normalized[1] == ":"):
        raise ValueError(
            f"Absolute path refused: {relative!r}. "
            f"Give a path relative to {base}"
        )
    if any(part == ".." for part in normalized.split("/")):
        raise ValueError(
            f"Path outside the workspace: {relative!r}. "
            f"Allowed root: {base}"
        )

    target = (base / normalized).resolve()
    if base != target and base not in target.parents:
        raise ValueError(
            f"Path outside the workspace: {relative!r}. "
            f"Allowed root: {base}"
        )
    return target


def _spec(name: str) -> Any:
    path = SCHEMAS / name
    if not path.exists():
        raise FileNotFoundError(
            f"Specification missing: {name}. "
            "Regenerate it with `python tools/spec_export.py`."
        )
    return json.loads(path.read_text(encoding="utf-8"))


_NOISE = ("@", "─", "━", "│", "┌", "└", "├", "═", "╔", "╚", "║", "•", "▄", "▀")


def _clean(output: str) -> str:
    """
    Retire le bandeau ASCII et les filets décoratifs de la CLI.

    Ces lignes sont faites pour l'œil humain. Rendues à un modèle, elles
    coûtent des jetons et noient le message utile — or c'est le message utile
    qui lui permet de corriger son erreur.
    """
    kept = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        letters = sum(c.isalnum() for c in stripped)
        if letters < max(3, len(stripped) // 4):
            continue
        if stripped[0] in _NOISE:
            continue
        kept.append(line.rstrip())
    return "\n".join(kept).strip()


def _hdrctl(*args: str) -> tuple[bool, str]:
    """Appelle la CLI Hydra en sous-processus, sortie normalisée."""
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    # Wide console: rich wraps long lines (paths) at 80 columns in a subprocess.
    env["COLUMNS"] = "4000"
    # The CLI runs in the workspace: a path that something still resolves from
    # the current folder stays inside it (it used to land in the Hydra ETL
    # install folder). ROOT stays importable for a source checkout.
    env["PYTHONPATH"] = os.pathsep.join(x for x in (str(ROOT), env.get("PYTHONPATH", "")) if x)
    proc = subprocess.run(
        [sys.executable, "-m", "hydra_etl.cli.hdrctl", *args],
        cwd=str(workspace()), capture_output=True, text=True,
        encoding="utf-8", errors="replace", env=env, timeout=600,
    )
    ok = proc.returncode == 0
    output = _clean(proc.stdout + proc.stderr)
    if not ok:
        # En cas d'echec, on ne rend que les lignes d'erreur. Le bandeau, les
        # vingt lignes « ok » et le compteur (qui annonce « 0 error(s) » tout
        # en signalant une erreur — anomalie A8 du produit) n'aident pas le
        # modele a se corriger : ils le desorientent.
        report = _validation_report(output)
        if report:
            output = report
        else:
            output = "\n".join(
                l for l in output.splitlines()
                if not l.strip().lower().startswith("ok ")
                and "dsl validation" not in l.lower()
                and "error(s) detected" not in l.lower()
                and "devops edition" not in l.lower()
            )
    return ok, _relative_paths(output)


# Shown under a refused manifest: the shape the validator expects.
EXPECTED_SHAPE = {
    "sources.yaml": """version: "1.0"
sources:
  orders:                       # any name; pipeline.from and join.right use it
    type: sqlite                # hydra_list_connectors gives every type
    connection:
      path: ../../data/app.db   # relative to the job folder
    extract:
      table: orders             # or query: SELECT ...""",
    "transformations.yaml": """version: "1.0"
steps:                          # ONE list, applied in order to the rows of pipeline.from
  - filter:
      expr: "status == 'ok'"
  - join:
      right: customers          # another source declared in sources.yaml
      key: customer_id
# every operation and its parameters: hydra_list_operations, hydra_describe_operation""",
    "destinations.yaml": """version: "1.0"
destinations:
  report:                       # any name; pipeline.to uses it
    type: csv
    load:
      table: ../../outputs/report.csv   # for a file: its path, relative to the job folder
      mode: replace             # append | replace | upsert (upsert needs key: [...])""",
    "pipeline.yaml": """version: "1.0"
pipeline:                       # a mapping, not a list: one source -> steps -> one destination
  from: orders                  # a source name (other sources come in through join)
  to: report                    # a destination name""",
}


def _validation_report(output: str) -> str:
    """Turns the CLI validation output into a report a model can act on.

    The CLI prints pydantic's details (which field, what is wrong) on lines
    that do not start with « err »: keeping only the « err » lines told the
    model « 2 validation errors for SourcesConfig » and nothing else. Here each
    problem is given with its location, and every refused manifest is followed
    by the shape it must have.
    """
    import re

    if " err " not in f" {output}" and "\nerr " not in output:
        return ""
    files: dict[str, list[str]] = {}
    current = None
    loc = None
    for raw in output.splitlines():
        line = raw.rstrip()
        s = line.strip()
        if not s or s.lower().startswith(("ok ", "for further information", "❌", "🔍")):
            continue
        if s.startswith("err "):
            body = s[4:].strip()
            m = re.match(r"^(\w+\.yaml)$", body)
            if m:
                current = m.group(1)
                files.setdefault(current, [])
                continue
            m = re.match(r"^(\w+\.yaml)\s*:\s*(.+)$", body)
            if m:
                current = m.group(1)
                files.setdefault(current, []).append(m.group(2))
                continue
            body = body.lstrip("→ ").strip()
            if re.match(r"^\d+ validation errors? for \w+$", body):
                continue
            files.setdefault(current or "job", []).append(body)
            continue
        if not raw.startswith(" ") and re.match(r"^[\w.\[\]-]+$", s):
            loc = s
            continue
        if loc and raw.startswith(" "):
            msg = re.sub(r"\s*\[type=.*$", "", s)
            hint = {"Field required": "missing",
                    "Extra inputs are not permitted": "unknown key here"}.get(msg, msg)
            files.setdefault(current or "job", []).append(f"{loc}: {hint}")
            loc = None
    if not any(files.values()):
        return ""
    out = []
    for name, problems in files.items():
        if not problems:
            continue
        out.append(f"{name}:")
        out += [f"  - {p}" for p in problems]
        if name in EXPECTED_SHAPE:
            out.append("  Expected shape:")
            out += ["    " + l for l in EXPECTED_SHAPE[name].splitlines()]
    return "\n".join(out)


# Connectors that only read (kept in sync by tests/test_mcp_server.py)
SOURCE_ONLY = ("postgres_cdc", "postgresql_cdc", "mysql_cdc", "web_api")

FILE_TYPES = ("csv", "json", "parquet", "sqlite")


def _rel(path: Path, start: Path) -> str:
    return os.path.relpath(path, start).replace("\\", "/")


def _inside(path: Path, root: Path) -> bool:
    try:
        Path(os.path.normpath(path)).relative_to(Path(os.path.normpath(root)))
        return True
    except ValueError:
        return False


_BASE_MARK = "\x00base:"  # marks a path built from a base_path (see _file_paths)


def _shown(p: str) -> str:
    return p[len(_BASE_MARK):] if p.startswith(_BASE_MARK) else p


def _at(base: Path, p: str) -> Path:
    """base/p with the « .. » folded: the job folder may not exist yet.

    A path built from a relative base_path starts from the project root."""
    if p.startswith(_BASE_MARK):
        from hydra_etl.workflow.project import project_root_for_paths

        p = p[len(_BASE_MARK):]
        if not Path(p).is_absolute():
            base = project_root_for_paths(base) or base
    return Path(os.path.normpath(base / p))


def _file_paths(doc: dict, kind: str):
    """(name, path) of the file sources or destinations of a manifest."""
    for name, v in ((doc or {}).get(kind) or {}).items():
        if not isinstance(v, dict) or v.get("type") not in FILE_TYPES:
            continue
        if v.get("type") == "sqlite":
            p = (v.get("connection") or {}).get("path") or (v.get("connection") or {}).get("database")
        else:
            p = ((v.get("extract") if kind == "sources" else v.get("load")) or {}).get("table")
            base = (v.get("connection") or {}).get("base_path") or v.get("base_path")
            if isinstance(p, str) and isinstance(base, str) and base and "{{" not in base \
                    and not Path(p).is_absolute():
                # base_path: absolute, or from the project root (the job folder outside a project)
                p = f"{_BASE_MARK}{base.rstrip('/')}/{p}"
        if isinstance(p, str) and p and "{{" not in p and "*" not in p and "://" not in p \
                and "://" not in str((v.get("connection") or {}).get("base_path") or ""):
            yield name, p                      # s3:// az:// gs:// : hors de l'espace de travail, non vérifié


def _misplaced_paths(job_dir: Path, sources: dict, destinations: dict) -> list:
    """Paths written from the project root instead of the job folder.

    `data/x.csv` in jobs/a is read as jobs/a/data/x.csv: the run fails, or an
    output lands inside the job folder. Caught here, before anything is written.
    """
    root = workspace()
    out = []
    for kind, doc in (("sources", sources), ("destinations", destinations)):
        for name, p in _file_paths(doc, kind):
            full = Path(p) if Path(p).is_absolute() else _at(job_dir, p)
            if not _inside(full, root):
                out.append(f"{kind}.{name}: '{_shown(p)}' is outside the workspace; the files of a job must be "
                           f"in it (data/, outputs/...), with paths relative to the job folder.")
    if out:
        return out
    for name, p in _file_paths(sources, "sources"):
        if p.startswith(_BASE_MARK):
            continue  # base_path has its own rule (project root): only « outside » and « missing » apply
        if not _at(job_dir, p).exists() and _at(root, p).exists():
            out.append(f"sources.{name}: '{p}' would be read as {_rel(_at(job_dir, p), root)}, which does not "
                       f"exist. Paths are relative to the job folder: write '{_rel(_at(root, p), job_dir)}'.")
    for name, p in _file_paths(destinations, "destinations"):
        if p.startswith(_BASE_MARK):
            continue
        if not _at(job_dir, p).parent.exists() and _at(root, p).parent.is_dir() and Path(p).parent != Path("."):
            out.append(f"destinations.{name}: '{p}' would be written to {_rel(_at(job_dir, p), root)}. "
                       f"Paths are relative to the job folder: write '{_rel(_at(root, p), job_dir)}'.")
    return out


def _with_inline_sources(sources: dict, transformations: dict) -> dict:
    """sources.yaml plus the sources written inline in a join / merge / union step."""
    out = {"sources": dict((sources or {}).get("sources") or {})}
    t = transformations if isinstance(transformations, dict) else {}
    steps = t.get("steps")
    if steps is None and isinstance(t.get("transformations"), dict):
        steps = t["transformations"].get("steps")
    for i, st in enumerate(steps or [], start=1):
        if not isinstance(st, dict):
            continue
        for op in ("join", "merge", "union"):
            right = (st.get(op) or {}).get("right") if isinstance(st.get(op), dict) else None
            if isinstance(right, dict) and right.get("type"):
                out["sources"][f"(step {i} {op}.right)"] = right
    return out


def _missing_sources(job_dir: Path, sources: dict) -> list:
    return [f"sources.{n}: {_rel(_at(job_dir, p), workspace())} does not exist yet "
            f"(fine if another job creates it before this one runs)"
            for n, p in _file_paths(sources, "sources") if not _at(job_dir, p).exists()]


def _workflow_job_paths(wf_file: Path, doc: dict):
    """Job paths of a workflow are relative to the workflow's folder."""
    root, base = workspace(), wf_file.parent
    wrong, notes = [], []
    steps = ((doc.get("workflow") or {}).get("steps") or []) if isinstance(doc, dict) else []
    for st in steps:
        if not isinstance(st, dict) or st.get("type") != "job" or not isinstance(st.get("job"), str):
            continue
        j = st["job"]
        if "{{" in j or Path(j).is_absolute() or _at(base, j).is_dir():
            continue
        if _at(root, j).is_dir():
            wrong.append(f"step {st.get('name', '?')}: job '{j}' would be {_rel(_at(base, j), root)}, which does "
                         f"not exist. Job paths are relative to the workflow's folder: write '{_rel(_at(root, j), base)}'.")
        else:
            notes.append(f"step {st.get('name', '?')}: job {_rel(_at(base, j), root)} does not exist yet")
    return wrong, notes


def _workflows_using(job_dir: Path) -> list:
    """The workflows of the workspace that run this job folder."""
    root = workspace()
    target = Path(os.path.normpath(job_dir))
    out = []
    skip = {".hydra", ".git", ".venv", "venv", "env", "node_modules", "__pycache__", "outputs", "Data", "data"}
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [n for n in dirnames if n not in skip and not n.startswith(".")]
        files += [Path(dirpath) / n for n in filenames if n.endswith((".yaml", ".yml"))]
    for f in sorted(files):
        try:
            doc = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        except Exception:  # noqa: BLE001 — an unreadable file is not a workflow we can check
            continue
        steps = ((doc.get("workflow") or {}).get("steps") or []) if isinstance(doc, dict) else []
        for st in steps:
            j = st.get("job") if isinstance(st, dict) and st.get("type") == "job" else None
            if isinstance(j, str) and "{{" not in j and _at(f.parent, j) == target:
                out.append(_rel(f, root))
                break
    return out


def _forget_job_in_project(root: Path, rel: str) -> None:
    """Drops the job from .hydra/project.json (the list the Studio reads)."""
    import json

    f = root / ".hydra" / "project.json"
    try:
        doc = json.loads(f.read_text(encoding="utf-8-sig"))
    except Exception:  # noqa: BLE001 — no project file, or not ours to fix
        return
    jobs = doc.get("jobs")
    if isinstance(jobs, list):
        keep = [j for j in jobs if not (isinstance(j, dict) and str(j.get("path", "")).replace("\\", "/") == rel)]
        if len(keep) != len(jobs):
            doc["jobs"] = keep
            f.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")


def _relative_paths(text: str) -> str:
    """Shows workspace paths relative to it: the model does not need the
    absolute path, and transcripts must not reveal the user's folders."""
    root = workspace()
    for form in {str(root), root.as_posix()}:
        text = text.replace(form + os.sep, "").replace(form + "/", "").replace(form, ".")
    return text


def _outputs_summary(job_dir: Path) -> str:
    """
    Décrit ce que le job a produit : fichier, lignes, colonnes.

    Sans cela, l'agent ne dispose que d'un journal d'exécution — de quoi dire
    « ça a marché », pas de quoi rédiger un rapport ni repérer une incohérence
    (zéro ligne écrite, par exemple, alors que la source en contenait).
    """
    manifest = job_dir / "destinations.yaml"
    if not manifest.exists():
        return ""
    try:
        doc = yaml.safe_load(manifest.read_text(encoding="utf-8")) or {}
        dests = doc.get("destinations") or {}
    except Exception:
        return ""

    lignes = []
    for name, defn in dests.items():
        if not isinstance(defn, dict):
            continue
        load = defn.get("load") or {}
        table = load.get("table")
        if not table:
            continue
        if defn.get("type") not in ("csv", "json", "parquet"):
            lignes.append(f"- {name}: {defn.get('type')} → {table}")
            continue
        path = (job_dir / str(table)) if not Path(str(table)).is_absolute() else Path(str(table))
        if not path.exists():
            lignes.append(f"- {name}: {table} — file not found after the run")
            continue
        try:
            import pandas as pd
            if path.suffix.lower() == ".csv":
                df = pd.read_csv(path)
            elif path.suffix.lower() == ".json":
                df = pd.read_json(path)
            else:
                df = pd.read_parquet(path)
            lignes.append(
                f"- {name}: {table} — {len(df)} rows, {len(df.columns)} columns "
                f"({', '.join(map(str, df.columns[:8]))})"
            )
            if len(df) == 0:
                lignes.append("  WARNING: zero rows written. A filter is probably "
                              "too strict, or a `cast` is missing.")
        except Exception as exc:
            lignes.append(f"- {name}: {table} — cannot be read ({type(exc).__name__})")

    if not lignes:
        return ""
    return "\n\nOutput produced:\n" + "\n".join(lignes)


# ---------------------------------------------------------------------------

def _preview_sqlite(f: Path, shown: str, table: str, rows: int) -> str:
    """Tables d'une base SQLite (colonnes, types SQL, nombre de lignes), et les
    premières lignes de `table`. Ouverture en lecture seule : rien n'est créé."""
    import sqlite3
    try:
        conn = sqlite3.connect(f"{f.as_uri()}?mode=ro", uri=True)
    except Exception as exc:
        return f"Cannot open the database: {type(exc).__name__}: {exc}"
    try:
        names = [r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table', 'view') "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        if not names:
            return f"Database: {shown}\nNo table."
        out = [f"Database: {shown}", "Tables:"]
        for n in names:
            cols = conn.execute(f'PRAGMA table_info("{n}")').fetchall()
            count = conn.execute(f'SELECT COUNT(*) FROM "{n}"').fetchone()[0]
            out.append(f"- {n} ({count} rows): " + ", ".join(
                f"{c[1]} {c[2] or 'ANY'}" for c in cols))
        if table:
            if table not in names:
                return "\n".join(out) + f"\n\nTable not found: {table!r}."
            cur = conn.execute(f'SELECT * FROM "{table}" LIMIT {rows}')
            header = [d[0] for d in cur.description]
            body = [" | ".join(header)] + [" | ".join("" if v is None else str(v) for v in r)
                                           for r in cur.fetchall()]
            out += ["", f"First {rows} rows of {table}:"] + body
        else:
            out += ["", "Give `table` to see the first rows of a table."]
        out += ["", "In a job: type: sqlite, connection.path relative to the job folder."]
        return "\n".join(out)
    finally:
        conn.close()


def build_server() -> Any:
    kwargs: dict[str, Any] = {
        "name": "hydra-etl",
        "instructions": (
            "Hydra ETL is a declarative ETL engine. A job is a folder holding "
            "four YAML manifests: sources.yaml, transformations.yaml "
            "(optional), destinations.yaml and pipeline.yaml.\n\n"
            "Recommended method: call hydra_list_operations and "
            "hydra_list_connectors first to learn the exact vocabulary, then "
            "write the job with hydra_write_job — it validates before writing "
            "and hands back the errors if anything is wrong. Never run a job "
            "unless the user asked for it.\n\n"
            "Never invent a connector, an operation or an action: if it is "
            "not in the lists, it does not exist."
        ),
    }
    # Champs portés par serverInfo dans le SDK 2.x. Le repli 1.x ne les
    # connaît pas et les refuserait : on ne les passe que s'ils existent.
    _accepted = inspect.signature(MCPServer.__init__).parameters
    for _key, _value in (("title", "Hydra ETL"),
                         ("version", __version__),
                         ("website_url", "https://hydraetl.com")):
        if _key in _accepted:
            kwargs[_key] = _value
    server = MCPServer(**kwargs)

    # -- Découverte du DSL ---------------------------------------------------

    @server.tool(
        description=(
            "List every transformation operation of Hydra ETL with its "
            "required parameters. Call this BEFORE writing a "
            "transformations.yaml: any operation missing from this list does "
            "not exist and will be rejected."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_list_operations() -> str:
        index = _spec("index.json")
        rows = []
        for entry in index["schemas"]:
            if entry["kind"] != "transformation":
                continue
            sch = _spec(entry["path"])
            required = ", ".join(sch.get("required", [])) or "—"
            rows.append(f"{entry['dslName']:<14} required: {required}")
        return "\n".join(sorted(rows))

    @server.tool(
        description=(
            "Return the full JSON schema of one transformation operation: "
            "every parameter, its type and its default value. Call this when "
            "hydra_list_operations is not enough."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_describe_operation(operation: str) -> str:
        path = SCHEMAS / "operations" / f"{operation}.schema.json"
        if not path.exists():
            known = sorted(p.stem.replace(".schema", "")
                           for p in (SCHEMAS / "operations").glob("*.json"))
            return (f"Unknown operation: {operation!r}.\n"
                    f"Existing operations: {', '.join(known)}")
        return json.dumps(_spec(f"operations/{operation}.schema.json"),
                          ensure_ascii=False, indent=2)

    @server.tool(
        description=(
            "List the connector types accepted by the 'type' key of a source "
            "or a destination. Any other type fails at run time: S3, for example, "
            "is not supported."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_list_connectors() -> str:
        sch = _spec("connectors.schema.json")
        both = [c for c in sch["enum"] if c not in SOURCE_ONLY]
        only = [c for c in sch["enum"] if c in SOURCE_ONLY]
        return ("Source and destination: " + ", ".join(both) + "\n"
                "Source only (cannot be a destination): " + ", ".join(only) + "\n"
                "Any other type is rejected: Hydra ETL has no connector for it.")

    @server.tool(
        description=(
            "List the actions usable in a workflow step of type 'action'. "
            "Any other name is rejected: the workflow fails validation and "
            "does not run."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_list_actions() -> str:
        sch = _spec("actions.schema.json")
        return ", ".join(sch["enum"])

    # -- Lecture -------------------------------------------------------------

    @server.tool(
        description=(
            "List the Hydra ETL jobs present in the workspace. A job is a "
            "folder holding a pipeline.yaml. Returns relative paths, usable "
            "as they are in the other tools."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_list_jobs() -> str:
        base = workspace()
        jobs = sorted(p.parent.relative_to(base).as_posix()
                      for p in base.rglob("pipeline.yaml")
                      if "_archive" not in p.parts and "_backups" not in p.parts)
        if not jobs:
            return f"No job found under {base}."
        return "\n".join(jobs)

    @server.tool(
        description=(
            "Read the manifests of an existing job. Call this before "
            "modifying a job, so you start from its real content instead of "
            "rewriting it from memory."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_read_job(job_path: str) -> str:
        try:
            d = safe_path(job_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not d.is_dir():
            return f"Folder not found: {job_path}"
        out = []
        for name in JOB_FILES:
            f = d / name
            if f.exists():
                out.append(f"### {name}\n{f.read_text(encoding='utf-8')}")
        return "\n\n".join(out) or f"No manifest in {job_path}."

    # -- Écriture, validation, exécution -------------------------------------

    @server.tool(
        description=(
            "Validate a job with the official Hydra ETL validator: the "
            "structure of the four manifests, and the resolution of "
            "pipeline.from to a declared source and of pipeline.to to a "
            "declared destination. This is the ground truth — if this tool "
            "refuses, the job will not run."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_validate_job(job_path: str) -> str:
        try:
            d = safe_path(job_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        ok, output = _hdrctl("validate", str(d))
        return ("VALIDE\n" if ok else "INVALIDE\n") + output

    @server.tool(
        description=(
            "Write the manifests of a job, AFTER validation. Each manifest "
            "is passed as YAML text. If validation fails, nothing is written "
            "and the errors are returned: fix them and call the tool again. "
            "Writing does not run the job."
        )
    ,
        annotations=_annot(**ECRITURE, title="Writes files, after validation"))
    def hydra_write_job(job_path: str,
                        sources_yaml: str,
                        destinations_yaml: str,
                        pipeline_yaml: str,
                        transformations_yaml: str = "") -> str:
        import shutil
        import tempfile

        files = {"sources.yaml": sources_yaml,
                 "destinations.yaml": destinations_yaml,
                 "pipeline.yaml": pipeline_yaml}
        if transformations_yaml.strip():
            files["transformations.yaml"] = transformations_yaml

        for name, content in files.items():
            try:
                yaml.safe_load(content)
            except Exception as exc:
                return f"REFUSED — {name} is not valid YAML: {exc}"

        tmp = Path(tempfile.mkdtemp(prefix="hydra_mcp_"))
        try:
            for name, content in files.items():
                (tmp / name).write_text(content, encoding="utf-8")
            ok, output = _hdrctl("validate", str(tmp))
            if not ok:
                return ("REFUSED — nothing was written. The validator reports:\n"
                        + output)
            try:
                target = safe_path(job_path)
            except ValueError as exc:
                return f"REFUSED — {exc}"
            src_doc = _with_inline_sources(yaml.safe_load(files["sources.yaml"]) or {},
                                           yaml.safe_load(files.get("transformations.yaml", "")) or {})
            dst_doc = yaml.safe_load(files["destinations.yaml"]) or {}
            wrong = _misplaced_paths(target, src_doc, dst_doc)
            if wrong:
                return "REFUSED — nothing was written.\n" + "\n".join(f"- {w}" for w in wrong)
            notes = _missing_sources(target, src_doc)
            target.mkdir(parents=True, exist_ok=True)
            for name, content in files.items():
                (target / name).write_text(content, encoding="utf-8")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

        written = ", ".join(sorted(files))
        return (f"WRITTEN to {job_path}: {written}.\n"
                f"The job is valid. It was not run — use "
                f"hydra_run_job if the user asks for it."
                + "".join(f"\nNote: {n}" for n in notes))

    @server.tool(
        description=(
            "Remove a job from the project. Nothing is destroyed: the job "
            "folder is moved to .hydra/trash/<date>/ and can be moved back. "
            "Refused while a workflow still runs the job: update the "
            "workflow first (hydra_write_workflow)."
        )
    ,
        annotations=_annot(**EXECUTION, title="Moves a job to the project trash"))
    def hydra_delete_job(job_path: str) -> str:
        import shutil
        from datetime import datetime

        try:
            d = safe_path(job_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        root = workspace()
        if not d.is_dir():
            return f"Folder not found: {job_path}"
        if not (d / "pipeline.yaml").is_file():
            return f"REFUSED — {job_path} is not a job folder (no pipeline.yaml); nothing was moved."
        users = _workflows_using(d)
        if users:
            return ("REFUSED — nothing was moved: " + ", ".join(users) + " still run this job. "
                    "Remove it from the workflow first (hydra_write_workflow), then delete it.")
        rel = _rel(d, root)
        trash = root / ".hydra" / "trash" / datetime.now().strftime("%Y%m%d-%H%M%S") / rel
        trash.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(d), str(trash))
        _forget_job_in_project(root, rel)
        return (f"MOVED to trash: {rel} -> {_rel(trash, root)}. "
                f"To restore it, move that folder back to {rel}.")

    @server.tool(
        description=(
            "Run a Hydra ETL job and return the execution log. Only call "
            "this tool if the user explicitly asked for the run: it writes "
            "real data to the destination."
        )
    ,
        annotations=_annot(**EXECUTION, title="Runs the pipeline — writes real data"))
    def hydra_run_job(job_path: str) -> str:
        try:
            d = safe_path(job_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        ok, output = _hdrctl("run", str(d))
        if not ok:
            return "FAILED\n" + output
        return "RUN SUCCEEDED\n" + output + _outputs_summary(d)

    @server.tool(
        description=(
            "Explain a Hydra ETL validation error in plain language and "
            "propose the fix. Use this when hydra_validate_job or "
            "hydra_write_job returns a message you cannot interpret."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_explain_error(error_message: str) -> str:
        hints = [
            ("cast", "A CSV file carries no types: put a `cast` step "
                     "BEFORE any numeric comparison or aggregation."),
            ("from", "`pipeline.from` must be exactly one of the identifiers "
                     "declared in sources.yaml."),
            ("to", "`pipeline.to` must be exactly one of the identifiers "
                   "declared in destinations.yaml."),
            ("type", "The `type` key must be one of the connectors listed "
                     "by hydra_list_connectors."),
            ("steps", "transformations.yaml expects a `steps` list, each "
                      "step being an object with ONE key only: the name of "
                      "the operation."),
            ("mode", "`load.mode` is append, replace or upsert."),
            ("order_by", "window: rank (row_number, rank, dense_rank), offset (lag, lead) "
                         "and running (cumsum, cumcount, cummin, cummax) functions need "
                         "`order_by`: a list of column names or {col, desc}."),
            ("max_rows", "join how: cross produces left rows x right rows. Filter the "
                         "inputs first, or raise `max_rows` if this size is intended. "
                         "`max_rows` is only allowed with how: cross."),
            ("cross", "join how: cross takes no key: remove `key`, `left_key` and "
                      "`right_key`."),
            ("text_to_rows", "text_to_rows needs `column` (the column to split); `sep` "
                             "is plain text unless `regex: true`; `index_column` must be "
                             "a new column name."),
            ("numeric column", "window: cumsum, cummin, cummax, sum and mean read a "
                               "numeric column. Add a `cast` step before the window."),
        ]
        low = error_message.lower()
        found = [h for key, h in hints if key in low]
        if not found:
            found = ["No known rule matches. Read the schema of the element "
                     "concerned with hydra_describe_operation."]
        return "\n".join(f"- {h}" for h in found)

    # -- Workflows -----------------------------------------------------------

    @server.tool(
        description=(
            "List the workflows in the workspace. A workflow orchestrates "
            "several jobs: dependencies, parallel execution, retries, cron "
            "triggering. Use this as soon as the request chains several jobs."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_list_workflows() -> str:
        base = workspace()
        found = []
        for f in base.rglob("*.yaml"):
            if f.name in JOB_FILES or "_archive" in f.parts or "_backups" in f.parts:
                continue
            try:
                doc = yaml.safe_load(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(doc, dict) and "workflow" in doc:
                found.append(f.relative_to(base).as_posix())
        return "\n".join(sorted(found)) or "No workflow found."

    @server.tool(
        description=(
            "Read an existing workflow.yaml file and return its raw YAML. "
            "Call this before modifying a workflow, so you start from its "
            "real content instead of rewriting it from memory."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_read_workflow(workflow_path: str) -> str:
        try:
            f = safe_path(workflow_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not f.is_file():
            return f"File not found: {workflow_path}"
        return f.read_text(encoding="utf-8")

    @server.tool(
        description=(
            "Write a workflow, AFTER validation. A step is either "
            "type='job' with the path of a job folder, or type='action'. "
            "`depends_on` is ALWAYS a list: steps with no dependency in "
            "common run in parallel. If validation fails, nothing is "
            "written."
        )
    ,
        annotations=_annot(**ECRITURE, title="Writes files, after validation"))
    def hydra_write_workflow(workflow_path: str, workflow_yaml: str) -> str:
        import shutil
        import tempfile

        try:
            yaml.safe_load(workflow_yaml)
        except Exception as exc:
            return f"REFUSED — the YAML is invalid: {exc}"

        tmp = Path(tempfile.mkdtemp(prefix="hydra_mcp_wf_"))
        try:
            candidate = tmp / "workflow.yaml"
            candidate.write_text(workflow_yaml, encoding="utf-8")
            ok, output = _hdrctl("workflow", "validate", str(candidate))
            if not ok:
                output = output.replace(str(candidate), workflow_path).replace(candidate.as_posix(), workflow_path)
                # Windows may print the temp folder another way (8.3 short name RUNNER~1)
                output = re.sub(r"[^\s'\"]*hydra_mcp_wf_[^\\/\s'\"]+[\\/]workflow\.yaml", workflow_path, output)
                return ("REFUSED — nothing was written. The validator reports:\n"
                        + output)
            try:
                target = safe_path(workflow_path)
            except ValueError as exc:
                return f"REFUSED — {exc}"
            wrong, notes = _workflow_job_paths(target, yaml.safe_load(workflow_yaml) or {})
            if wrong:
                return "REFUSED — nothing was written.\n" + "\n".join(f"- {w}" for w in wrong)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(workflow_yaml, encoding="utf-8")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

        return (f"WRITTEN: {workflow_path}. The workflow is valid and was "
                f"not run." + "".join(f"\nNote: {n}" for n in notes))

    @server.tool(
        description=(
            "Run a workflow and return the trace, step by step. Only call "
            "this tool if the user asked for the run: the jobs it contains "
            "write real data to their destinations. `env` selects the "
            "environment (dev, prod…), like `hdrctl workflow run --env`; "
            "list them with hydra_project_settings."
        )
    ,
        annotations=_annot(**EXECUTION, title="Runs the pipeline — writes real data"))
    def hydra_run_workflow(workflow_path: str, env: str = "") -> str:
        try:
            f = safe_path(workflow_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        args = ["workflow", "run", str(f)]
        if env:
            from hydra_etl.internal.config.loader import check_env_name
            try:
                args += ["--env", check_env_name(env)]
            except ValueError as exc:
                return f"REFUSED — {exc}"
        ok, output = _hdrctl(*args)
        return ("RUN SUCCEEDED\n" if ok else "FAILED\n") + output

    # -- Environnements, paramètres, secrets (lecture seule) -----------------

    @server.tool(
        description=(
            "Show the environments, parameters and secrets of a Hydra "
            "project, read-only. Returns: the environments (dev, prod…), the "
            "NAMES of the global environment variables (~/.hydra/env, "
            "env.<env>), the parameters with their type, default and value "
            "per environment, and the NAMES of the secrets (common or per "
            "environment). Secret values and variable values are never "
            "returned. Call this before writing a job that needs a "
            "connection: use ${ENV:NAME}, ${SECRET:NAME} and "
            "{{ param:NAME }} with names that exist. `env` adds the effective "
            "parameter values for that environment."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_project_settings(project_path: str = ".", env: str = "") -> str:
        from hydra_etl.internal.config import env_admin as ea
        from hydra_etl.internal.config.loader import check_env_name, global_env_file
        from hydra_etl.internal.config.parameters import ParameterError, build_effective
        try:
            root = safe_path(project_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not (root / ".hydra").is_dir():
            return (f"Not a Hydra project: {project_path} (no .hydra/ folder). "
                    "Give the folder that contains .hydra/.")
        if env:
            try:
                env = check_env_name(env)
            except ValueError as exc:
                return f"REFUSED — {exc}"
        try:
            envs = ea.list_environments(root)
            view = ea.read_parameters(root)
            secrets = ea.list_secrets(root, env or None)
        except ea.EnvAdminError as exc:
            return f"ERROR — {exc}"
        except Exception as exc:  # fichier de secrets illisible, etc.
            return f"ERROR — {type(exc).__name__}: {exc}"

        out = [f"Project: {root.name}"]
        out.append("\nEnvironments (select with --env, HYDRA_ENV or the Studio selector):")
        if not envs:
            out.append("  (none) — runs use the defaults only")
        for e in envs:
            out.append(f"  {e.name}: {e.global_vars} global variable(s), "
                       f"{e.params} parameter value(s), {e.secrets} secret(s)")

        def _names(scope):
            try:
                return sorted(ea.global_vars(scope))
            except Exception:
                return []
        out.append("\nGlobal environment variables — names only, use ${ENV:NAME}:")
        out.append(f"  common ({global_env_file(None)}): {', '.join(_names(None)) or '—'}")
        for e in envs:
            if e.global_file:
                out.append(f"  {e.name}: {', '.join(_names(e.name)) or '—'}")

        out.append("\nParameters — use {{ param:NAME }}:")
        if not view.declarations:
            out.append("  (none)")
        effective = {}
        if env:
            try:
                effective = build_effective(view.declarations, [view.environments.get(env, {})])
            except ParameterError as exc:
                out.append(f"  ! {exc}")
        for name, d in view.declarations.items():
            per_env = ", ".join(f"{en}={vals[name]!r}" for en, vals in sorted(view.environments.items())
                                if name in vals)
            line = (f"  {name}: type={d.get('type', 'any')}, default={d.get('default')!r}"
                    + (", required" if d.get("required") else "")
                    + (f", per environment: {per_env}" if per_env else ""))
            if env:
                line += f" -> effective in {env}: {effective.get(name)!r}"
            out.append(line)

        out.append("\nSecrets — names only, use ${SECRET:NAME}:")
        if not secrets:
            out.append("  (none)")
        for s_ in secrets:
            extra = f" (overridden by the variable {s_.overridden_by})" if s_.overridden_by else ""
            out.append(f"  {s_.name} [{s_.scope}]{extra}")
        if not env and envs:
            out.append("  (pass env to also see the secrets of one environment)")
        return "\n".join(out)

    # -- Sous-projets (lecture seule) ----------------------------------------

    @server.tool(
        description=(
            "Show the projects a Hydra project calls through its "
            "`type: project` steps, read-only: the tree of called projects "
            "(with the workflows they run), then the problems — a called "
            "project that cannot be found, a cycle (A → B → A), nesting deeper "
            "than 5 levels — and the calls computed at run time. Without "
            "`workflow`: the workflows a run of the project would start "
            "(thread.yaml). Call this before adding a project step, and after "
            "writing one, to check it creates no cycle."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_project_calls(project_path: str = ".", workflow: str = "") -> str:
        from hydra_etl.workflow.subprojects import check_project_calls, project_calls
        try:
            root = safe_path(project_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not (root / ".hydra").is_dir():
            return (f"Not a Hydra project: {project_path} (no .hydra/ folder). "
                    "Give the folder that contains .hydra/.")
        only = [workflow.strip()] if workflow.strip() else None
        try:
            calls = project_calls(root, only)
            res = check_project_calls(root, workflows=only)
        except Exception as exc:  # workflow introuvable, YAML illisible…
            return f"ERROR — {type(exc).__name__}: {exc}"

        out = [f"Project: {root.name}" + (f" (workflow {only[0]})" if only else "")]
        out.append("\nProject steps:")
        if not calls:
            out.append("  (none) — this project calls no other project")
        for c in calls:
            if c.error:
                target = f"NOT FOUND — {c.error}"
            elif c.dynamic:
                target = "computed at run time"
            elif c.target is not None:
                try:
                    target = str(c.target.relative_to(root.parent))
                except ValueError:
                    target = str(c.target)
            else:
                target = "—"
            wfs = f", workflows: {', '.join(c.workflows)}" if c.workflows else ""
            out.append(f"  workflows/{c.workflow}.yaml › {c.step}: "
                       f"project={c.value!r} (ref: {c.ref}) -> {target}{wfs}")
        if res.tree:
            out.append("\nCalled projects:")
            out.append(f"  {root.name}")
            for depth, label in res.tree:
                out.append(f"  {'   ' * depth}↳ {label}")
        if res.errors:
            out.append("\nErrors (the run would be refused):")
            out.extend(f"  - {e}" for e in res.errors)
        if res.warnings:
            out.append("\nWarnings:")
            out.extend(f"  - {w}" for w in res.warnings)
        if calls and not res.errors:
            out.append("\nOK — no cycle, every called project found.")
        return "\n".join(out)

    # -- Déclencheurs de projet (lecture seule) -------------------------------

    @server.tool(
        description=(
            "Show the triggers of a Hydra project (triggers.yaml), read-only: "
            "each trigger with its type and event (cron, interval, file, marker, "
            "source_change, webhook, after_project), what it runs (environment, "
            "workflows), its next run for cron and interval, its last run from "
            "the history, then the problems that `hdrctl trigger validate` would "
            "report. Token values are never returned (names only). Call this "
            "before writing or changing triggers.yaml, and after, to check it."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_project_triggers(project_path: str = ".") -> str:
        from datetime import datetime, timezone
        from hydra_etl.triggers.core import check_triggers, last_runs
        from hydra_etl.triggers.engine import next_time
        from hydra_etl.triggers.models import TriggerFileError, load_triggers
        try:
            root = safe_path(project_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not (root / ".hydra").is_dir():
            return (f"Not a Hydra project: {project_path} (no .hydra/ folder). "
                    "Give the folder that contains .hydra/.")
        try:
            tf = load_triggers(root)
        except TriggerFileError as exc:
            return "triggers.yaml is invalid:\n" + "\n".join(f"  - {e}" for e in exc.errors)
        if not tf.triggers:
            return (f"Project: {root.name}\nNo trigger (no triggers.yaml, or an empty one). "
                    "Triggers run the project at a time, on a file, a source change, a webhook "
                    "or after another project; they run inside hdrctl watch / hdrctl serve.")
        check = check_triggers(root, tf)
        last = last_runs(root)
        now = datetime.now(timezone.utc)
        out = [f"Project: {root.name}", "", "Triggers:"]
        for t in tf.triggers:
            state = "on" if t.enabled else "off"
            out.append(f"  [{state}] {t.name} ({t.type}): {t.when()}")
            out.append(f"      runs: {', '.join(t.workflows) if t.workflows else 'thread.yaml'}"
                       f" · env: {t.env or 'from watch/serve'} · overlap: {t.overlap}"
                       + (f" · retry: {t.retry.max} x {t.retry.delay}" if t.retry else ""))
            if t.type == "webhook":
                out.append(f"      token: secret '{str(t.token).strip()[9:-1]}' (value never shown)")
            if t.enabled and t.type in ("cron", "interval"):
                try:
                    nxt = next_time(t, now)
                    if t.type == "cron" and nxt:
                        out.append(f"      next run: {nxt.astimezone().strftime('%Y-%m-%d %H:%M')}")
                except Exception:  # noqa: BLE001
                    pass
            e = last.get(t.name)
            if e:
                out.append(f"      last run: {e.get('status')} at {e.get('at')} ({e.get('origin')})"
                           + (f" — {e.get('error')}" if e.get("error") else ""))
        if check.errors:
            out.append("\nErrors (hdrctl trigger validate fails):")
            out.extend(f"  - {x}" for x in check.errors)
        if check.warnings:
            out.append("\nWarnings:")
            out.extend(f"  - {x}" for x in check.warnings)
        if not check.errors:
            out.append("\nOK — triggers valid.")
        return "\n".join(out)

    # -- Voir les données ----------------------------------------------------

    @server.tool(
        description=(
            "Show the columns and the first rows of a data file (CSV, JSON, "
            "Parquet) or of a SQLite database (.db, .sqlite: its tables, their "
            "columns with their SQL types and row counts; give `table` to see "
            "its first rows). Call this BEFORE writing a job, to learn the real "
            "column names instead of guessing them — and AFTER a run, to "
            "check the result."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_preview_data(file_path: str, rows: int = 5, table: str = "") -> str:
        try:
            f = safe_path(file_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not f.is_file():
            return f"File not found: {file_path}"
        if f.suffix.lower() in (".db", ".sqlite", ".sqlite3"):
            return _preview_sqlite(f, file_path, table, max(1, min(int(rows), 50)))
        try:
            import pandas as pd
        except ModuleNotFoundError:
            return "pandas is required to preview data."

        rows = max(1, min(int(rows), 50))
        suffix = f.suffix.lower()
        try:
            if suffix == ".csv":
                df = pd.read_csv(f, nrows=rows)
                total = sum(1 for _ in f.open(encoding="utf-8", errors="replace")) - 1
            elif suffix == ".json":
                df = pd.read_json(f).head(rows)
                total = None
            elif suffix in (".parquet", ".pq"):
                df = pd.read_parquet(f).head(rows)
                total = None
            else:
                return (f"Unsupported format: {suffix}. "
                        "Readable formats: .csv, .json, .parquet")
        except Exception as exc:
            return f"Cannot read the file: {type(exc).__name__}: {exc}"

        cols = ", ".join(f"{c} ({df[c].dtype})" for c in df.columns)
        head = df.to_string(index=False, max_colwidth=30)
        compte = f"\nTotal rows: {total}" if total is not None else ""
        return (f"File: {file_path}\nColumns: {cols}{compte}\n\n"
                f"First {rows} rows:\n{head}\n\n"
                "Reminder: a CSV file carries no types. The types above are "
                "guessed by the reader, not guaranteed — put a `cast` before "
                "any numeric comparison.")

    # -- Vérifier la cohérence avec la demande -------------------------------

    @server.tool(
        description=(
            "Check that a job does what the user actually asked for. This "
            "completes hydra_validate_job: that one says whether the YAML is "
            "correct, this one whether the job answers the request. Twelve "
            "deterministic rules: operation requested but missing, numeric "
            "comparison without a `cast`, load mode contradicted, "
            "inconsistent file extension, plaintext secret, unsupported "
            "technology. Call this AFTER writing a job, before presenting "
            "it."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_check_job(user_request: str, job_path: str) -> str:
        from hydra_etl.ai.guards import check

        try:
            d = safe_path(job_path)
        except ValueError as exc:
            return f"REFUSED — {exc}"
        if not d.is_dir():
            return f"Folder not found: {job_path}"

        files, docs = {}, {}
        for name in (*JOB_FILES, "workflow.yaml"):
            f = d / name
            if not f.exists():
                continue
            text = f.read_text(encoding="utf-8")
            files[name] = text
            try:
                docs[name] = yaml.safe_load(text)
            except Exception:
                docs[name] = None

        alerts = check(user_request, files, docs)
        if not alerts:
            return ("NO ALERT — the job looks consistent with the request. "
                    "Present it to the user.")
        return ("ALERTS — check them before presenting the job:\n"
                + "\n".join(f"- {a}" for a in alerts))

    # -- S'inspirer des jobs existants ---------------------------------------

    @server.tool(
        description=(
            "Find, among real Hydra ETL jobs, the ones closest to the "
            "request, and return their manifests. Call this BEFORE writing "
            "an unusual job: an example that runs beats a reconstruction "
            "from memory."
        )
    ,
        annotations=_annot(**LECTURE, title="Read-only"))
    def hydra_find_example(user_request: str, count: int = 2) -> str:
        from hydra_etl.ai.guards import OP_HINTS, _norm

        if not CORPUS.exists():
            return ("No example corpus. Generate it with "
                    "`python eval/corpus/harvest.py`.")

        besoin = {op for op, hints in OP_HINTS.items()
                  if any(h in _norm(user_request) for h in hints)}

        entries = []
        for line in CORPUS.read_text(encoding="utf-8").splitlines():
            try:
                e = json.loads(line)
            except Exception:
                continue
            if not e.get("valid") or e.get("expectedInvalid"):
                continue
            ops = set(e.get("features", {}).get("ops", []))
            score = len(besoin & ops) * 10

            # Sans indice d'opération, on retombe sur les mots de la demande :
            # un modèle qui demande « postgres » doit voir un exemple postgres.
            if not besoin:
                blob = json.dumps(e, ensure_ascii=False).lower()
                score = sum(2 for mot in _norm(user_request).split()
                            if len(mot) > 4 and mot in blob)

            # Un job vaut mieux qu'un workflow quand rien n'indique le contraire.
            if e.get("kind") == "job":
                score += 3
            score -= abs(len(ops) - len(besoin))
            entries.append((score, len(json.dumps(e)), e))

        if not entries:
            return "No usable example in the corpus."
        entries.sort(key=lambda t: (-t[0], t[1]))   # meilleur score, puis plus court

        count = max(1, min(int(count), 3))
        out = []
        for _, _, e in entries[:count]:
            manifests = "\n".join(f"# {n}\n{c}" for n, c in e["manifests"].items())
            out.append(f"### Example: {e['id']}\n{manifests}")
        return "\n\n".join(out)

    return server


def main() -> None:
    """
    Point d'entrée `hydra-mcp`.

    Deux transports, pour deux usages :

    - **stdio** (défaut) — le client démarre le serveur lui-même. C'est le mode
      des clients de bureau : Claude Desktop, Cursor, VS Code. Rien n'écoute
      sur le réseau.
    - **streamable-http** — le serveur écoute, le client s'y connecte. C'est ce
      qu'exigent les clients qui ne lancent pas de processus local, ChatGPT par
      exemple.

    Le mode HTTP n'a AUCUNE authentification : il est prévu pour la machine de
    l'utilisateur ou un tunnel maîtrisé, pas pour une exposition publique. Le
    serveur MCP distant, authentifié et multi-locataire, relève de l'édition
    commerciale.
    """
    import argparse

    ap = argparse.ArgumentParser(
        prog="hydra-mcp",
        description="Hydra ETL MCP server — exposes the engine to an AI agent.")
    ap.add_argument("--transport", choices=["stdio", "streamable-http", "sse"],
                    default="stdio",
                    help="stdio for a desktop client, streamable-http for a "
                         "remote client")
    ap.add_argument("--host", default="127.0.0.1",
                    help="listen address in HTTP mode (default: local only)")
    ap.add_argument("--port", type=int, default=8787)
    ap.add_argument("--workspace", default="",
                    help="working directory; same as HYDRA_MCP_WORKSPACE")
    args = ap.parse_args()

    if args.workspace:
        os.environ["HYDRA_MCP_WORKSPACE"] = args.workspace

    server = build_server()
    if args.transport == "stdio":
        server.run(transport="stdio")
        return

    if args.host not in ("127.0.0.1", "localhost", "::1"):
        print(f"Warning: listening on {args.host} with no authentication. "
              f"Do not expose this port publicly.", file=sys.stderr)
    # Le SDK 2.x ne porte plus host/port dans les réglages : ils se passent
    # au lancement, et sont relayés à l'application ASGI.
    server.run(transport=args.transport, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
